package userInterface;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.JPanel;

import model.*;

@SuppressWarnings("serial")
public class Camp extends JPanel implements MouseListener{
	private ArrayList<ObjPac> pacs;
	private Main main;
	
	public Camp(Main main1){
		main = main1;
		pacs = new ArrayList<>();
		addMouseListener(this);
	}
	
	public void changePacs(ArrayList<ObjPac> pac) {
		pacs = pac;
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.setColor(Color.BLACK);
		g.setFont(new Font("Serief", Font.PLAIN, 12));
		g.drawString("Rebounds: "+ main.darTotalRebotes(), 5, 15);
		for (int i = 0; pacs != null && i < pacs.size(); i++) {
			g.fillArc(pacs.get(i).getPosX(), pacs.get(i).getPosY(),main.width(), main.large(), 60, 60);
			g.setColor(Color.YELLOW);
			g.drawArc(pacs.get(i).getPosX(), pacs.get(i).getPosY(),main.width(), main.large(), 60, 60);
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if(!pacs.isEmpty())
			main.cathcPac(e.getX(), e.getY());
	}

	@Override
	public void mouseEntered(MouseEvent e){}

	@Override
	public void mouseExited(MouseEvent e){}

	@Override
	public void mousePressed(MouseEvent e){}

	@Override
	public void mouseReleased(MouseEvent e){}
	
}
