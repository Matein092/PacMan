package userInterface;

import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener;

import javax.swing.JMenu;
import javax.swing.JMenuItem;

@SuppressWarnings("serial")
public class MenuView extends JMenu implements ActionListener{
	
	private JMenuItem hallOfFame;
	private JMenuItem about;
	
	public final static String HALL_OF_FAME  = "Hall Of Fame";
	public final static String ABOUTOF = "About";
	
	private Main main;
	
	public MenuView(Main m) {
		super("view");

		main = m;
		
		hallOfFame  = new JMenuItem("Mejores puntajes");
		about = new JMenuItem("Acerca del Juego");
		
		hallOfFame.addActionListener(this);
		about.addActionListener(this);
		
		hallOfFame.setActionCommand(HALL_OF_FAME);
		about.setActionCommand(ABOUTOF);
		
		add(hallOfFame);
		add(about);
	}
	
	@Override
	public void actionPerformed(ActionEvent evento) {
		String msg = evento.getActionCommand();
		if(msg.equals(ABOUTOF)){
			main.showAboutTheGame();
		}else if(msg.equals(HALL_OF_FAME)){
			main.ShowBetterPoints();
		}
	}

}