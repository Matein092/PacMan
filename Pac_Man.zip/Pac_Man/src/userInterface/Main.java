package userInterface;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;

import pacHilos.*;
import model.*;

	@SuppressWarnings("serial")
	public class Main extends JFrame {

		private Game game;
		private Camp camp;
		private MenuFile menuFile;
		private MenuView menuView;
		
		public Main(){
			super("Catch the pacs!");
			setLayout(new BorderLayout());
			setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			
			game = 	new Game();
			camp = new Camp(this);
			menuFile = new MenuFile(this);
			menuView = new MenuView(this);
			
			JMenuBar miMenuBar = new JMenuBar();
			miMenuBar.add(menuFile);
			miMenuBar.add(menuView);
			setJMenuBar(miMenuBar);
			
			add(camp, BorderLayout.CENTER);
			
			setSize(500,400);
			
		}
		
		public boolean chargeTheFile(){
			boolean chargeA = false;
			JFileChooser fileCh = new JFileChooser("./data");
			int opcion = fileCh.showOpenDialog(this);
			
			switch(opcion){	
				case JFileChooser.APPROVE_OPTION:
					File f = fileCh.getSelectedFile();
					try{
						game.chargeGame(f);
						camp.changePacs(game.getPacs());
						createAndInitializeHilos();
						camp.repaint();
						chargeA = true;
					}catch(Exception ioexc){
						JOptionPane.showMessageDialog(this, "Problems reading the file\nProbably the file is invalid.");
					}
				break;
				case JFileChooser.CANCEL_OPTION:				
				break;
				case JFileChooser.ERROR_OPTION:
				break;
			}
			return chargeA;
		}
		
		private void createAndInitializeHilos(){
			HilosPacMan[] hilos = new HilosPacMan[game.getPacs().size()];
			for (int i = 0; i < hilos.length; i++) {
				hilos[i] = new HilosPacMan(this, game.getPacs().get(i));
				hilos[i].start();
			}
		}
		
		public void clearP() {
			camp.repaint();
		}
		
		public boolean saveFile(){
			boolean saveF = false;
			JFileChooser fileCh = new JFileChooser("./data");
			fileCh.setSelectedFile(new File("GameSave_"+(new SimpleDateFormat("yyyy-MM-dd_hh-mm-ss").format(new Date()))+".txt"));
			int o = fileCh.showSaveDialog(this);
			
			switch(o){	
				case JFileChooser.APPROVE_OPTION:
					File f = fileCh.getSelectedFile();
					try{
						game.saveGame(f);
						saveF = true;
					}catch(Exception ioexc){
						JOptionPane.showMessageDialog(this, "Problemas guardando el archivo\nEs probable que no tenga permisos de escritura o\nel archivo puede estar bloqueado por otro programa.");
					}
				break;
				case JFileChooser.CANCEL_OPTION:				
				break;
				case JFileChooser.ERROR_OPTION:
				break;
			}
			return saveF;		
		}
		
		public void exit(){
			int o = 0;
			boolean saved =false;
			do{
				o = JOptionPane.showConfirmDialog(this, "�Do you want to save the game before you go out?");
				if(o == JOptionPane.YES_OPTION){
					saved = saveFile();
				}
			}while(o == JOptionPane.YES_OPTION && !saved);
			
			if(o == JOptionPane.YES_OPTION ||o ==JOptionPane.NO_OPTION){
				System.exit(0);
			}
		}
		
		public void ShowBetterPoints(){
			String points;
			points = game.getPointers();
			JOptionPane.showMessageDialog(this, points);
		}
		
		public void showAboutTheGame(){
			JOptionPane.showMessageDialog(this, "This game is about cathc pac-man, by Mateo Ramirez");
		}
		
		public int width(){
			return getContentPane().getWidth();
		}
		
		public int large(){
			return getContentPane().getHeight();
		}
		
		public int darTotalRebotes(){
			int rebounds;
			rebounds = game.calculateTotalRebounds();
			return rebounds;
		}
		
		public void cathcPac(int x, int y){
			game.catched(x, y);
			if(game.endOfTheGame()){
				if(game.savePoints()){
					int actualPoints = game.calculateTotalRebounds();
					String name;
					do{
						name = JOptionPane.showInputDialog("Your points are : "+ actualPoints +" is in the Hall of Fame.\nWrite here your name:");
					}while(name == null || name.equals(""));
					
					game.saveActualPoint(name);
				}
			}
		}
		
		public void dispose(){
			try{
				ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(game.RUT));
				out.writeObject(game.getPoints());
				out.close();
			}catch(Exception e){
				JOptionPane.showMessageDialog(this, "You cant be save of the hall of fame");
			}
			exit();
		}
		
		public static void main(String[] args){
			Main main;
			main = new Main();
			main.setVisible(true);
			main.centrar();
		}
		
		 private void centrar(){
		    Dimension screen = Toolkit.getDefaultToolkit( ).getScreenSize( );
		    int x = ( screen.width - getWidth( ) ) / 2;
		    int y = ( screen.height - getHeight( ) ) / 2;
		    setLocation(x, y);
		}

	}
