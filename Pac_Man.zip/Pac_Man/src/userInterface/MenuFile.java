package userInterface;

import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener;

import javax.swing.JMenu;
import javax.swing.JMenuItem;

@SuppressWarnings("serial")
public class MenuFile extends JMenu implements ActionListener{
	
	private JMenuItem charge;
	private JMenuItem save;
	private JMenuItem exit;
	
	public final static String CHARGE  = "CHARGE";
	public final static String SAVE = "SAVE";
	public final static String EXIT   = "EXIT";
	
	private Main main;
	
	public MenuFile(Main m) {
		super("File");

		main = m;
		
		charge  = new JMenuItem("Charge Game");
		save = new JMenuItem("Save Game");
		exit   = new JMenuItem("Exit");
		
		charge.addActionListener(this);
		save.addActionListener(this);
		exit.addActionListener(this);
		
		charge.setActionCommand(CHARGE);
		save.setActionCommand(SAVE);
		exit.setActionCommand(EXIT);
		
		add(charge);
		add(save);
		addSeparator();
		add(exit);
	}
	
	@Override
	public void actionPerformed(ActionEvent evento) {
		String comando = evento.getActionCommand();
		if(comando.equals(CHARGE)){
			main.chargeTheFile();
		}else if(comando.equals(SAVE)){
			main.saveFile();
		}else if(comando.equals(EXIT)){
			main.exit();
		}
	}

}
