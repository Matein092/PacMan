package model;

public class ObjPac {
	
	public final static String LEFT = "LEFT";
	public final static String RIGHT = "RIGHT";
	public final static String UP = "UP";
	public final static String DOWN = "DOWN";
	
	private int posX;
	private int posY;
	private int waitTime;
	private String direction;
	private int radius;
	private boolean catched;
	private int rebound;
	
	public ObjPac(int posX,int posY,int waitTime,String direction,int radius,boolean catched, int rebound) {
		this.posX = posX;
		this.posY = posY;
		this.waitTime = waitTime;
		this.direction = direction;
		this.radius = radius;
		this.catched = catched;
		this.rebound = rebound;
	}
	
	public int getPosX() {
		return posX;
	}
	
	public int getPosY() {
		return posY;
	}
	
	public int getWaitTime() {
		return waitTime;
	}
	
	public String getDirection() {
		return direction;
	}
	
	public int getRadius() {
		return radius;
	}
	
	public boolean getCatched() {
		return catched;
	}
	
	public int getRebound() {
		return rebound;
	}
	
	public void setPosX(int posX) {
		this.posX = posX;
	}
	
	public void setPosY(int posY) {
		this.posY = posY;
	}
	
	public void setWaitTime(int waitTime) {
		this.waitTime = waitTime;
	}
	
	public void setDirection(String direction) {
		this.direction = direction;
	}
	
	public void setRadius(int radius) {
		this.radius = radius;
	}
	
	public void setCatched(boolean catched) {
		this.catched = catched;
	}
	
	public void setRebound(int rebound) {
		this.rebound = rebound;
	}
	
	public void movePac(int width, int large) {
		int movement = 1;
		switch(direction) {
		case LEFT:
			posX -= movement;
		break;
		case RIGHT:
			posX += movement;
		break;
		case UP:
			posY -= movement;
		break;
		case DOWN:
			posY += movement;
		break;
		}
		ifIsOutOfGame(width,large);
	}
	
	public void ifIsOutOfGame(int width,int large) {
		if((radius + posX) > width) {
			direction = LEFT;
			posX = (width - radius);
			rebound ++;
		}
		if(posX < 0) {
			direction = RIGHT;
			posX = 0;
			rebound++;
		}
		if((posY + radius) > large) {
			direction = UP;
			posY = large - radius;
			rebound++;
		}
		if(posY < 0) {
			direction = DOWN;
			posY = 0;
			rebound++;
		}
	}
	
	public boolean catchAPac(int x, int y) {
		boolean isCatch = false;
		if(posX <= x && x <= (posX + radius) && posY <= y && y <= (posY + radius)) {
			isCatch = true;
		}
		return isCatch;
	}
	
}
