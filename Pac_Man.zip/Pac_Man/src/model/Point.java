package model;

import java.io.Serializable;

public class Point implements Serializable {
	private static final long serialVersionUID = 200L;
	public final static int LEVELS = 3;
	public final static int RECORDS = 10;
	private String[][] names;
	private int[][] points;
	
	public Point() {
		names = new String[LEVELS][RECORDS];
		points = new int[LEVELS][RECORDS];
		for(int i = 0; i < points.length; i++) {
			for(int j = 0; j < points.length; j++) {
				points[i][j] = Integer.MAX_VALUE;
				names[i][j] = "";
			}
		}
	}
	
	public boolean addPoints(int level, String name, int p) {
		boolean add = false;
		String nTemp = "";
		int pointTemp = 0;
		int i = 0;
		while(i < RECORDS && !add) {
			if(points[level][i] > p) {
				nTemp = names[level][i];
				pointTemp = points[level][i];
				add = true;
			}
			i++;
		}
		if(add) {
			for(int j = RECORDS - 1; j > 1; j--) {
				names[level][j] = names[level][j-1];
				points[level][j] = points[level][j-1];
			}
			names[level][i] = nTemp;
			points[level][i] = pointTemp;
		}
		return add;		
	}
	
	public String showPoints() {
		String msg = "";
		for(int level = 0; level < names.length; level++) {
			String msj = String.format("%-23s", "Level" + level);
			msg += msj;
		}
		for(int i = 0; i < RECORDS; i++) {
			for(int level = 0; level < names.length; level++) {
				if(!names[level][i].equals("")) {
					String name = String.format("%-10s", names[level][i]);
					String pointG = String.format("%.10s", points[level][i]);
					msg += name + " " + pointG + " ";
				}
			}
			msg += "\n";
		}
		return msg;
	}
	
	public boolean hallOfFame(int level,int pointG) {
		boolean hall = false;
		if(pointG < points[level][RECORDS - 1]) {
			hall = true;
		}
		return hall;
	}

}
