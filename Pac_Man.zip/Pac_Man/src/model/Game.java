package model;

import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.File;


public class Game {
	public final static String RUT = "./data/point.catch";
	
	private ArrayList<ObjPac> pacs;
	private Point points;
	private int level;
	
	public Game() {
		pacs = new ArrayList<ObjPac>();
		points = new Point();
		level = 0;
		chargePoints();
	}
	
	public ArrayList<ObjPac> getPacs(){
		return pacs;
	}
	
	public Point getPoints() {
		return points;
	}
	
	public int getLevel() {
		return level;
	}
	
	public void setPacs(ArrayList<ObjPac> pacs) {
		this.pacs = pacs;
	}
	
	public void setPoints(Point points) {
		this.points = points;
	}
	
	public void setLevel(int level) {
		this.level = level;
	}
	
	public void chargePoints() {
		try {
			ObjectInputStream inObj = new ObjectInputStream(new FileInputStream(RUT));
			points = (Point) inObj.readObject();
			inObj.close();
		}
		catch(Exception exception) {
		}
	}
	
	public void chargeGame(File file) throws IOException{
		pacs = new ArrayList<ObjPac>();
		FileReader fRead = new FileReader(file);
		BufferedReader bfRead = new BufferedReader(fRead);
		String line = bfRead.readLine().trim();
		level = (line.charAt(0) == '#') ? Integer.parseInt(bfRead.readLine().trim()) : Integer.parseInt(line);
		line = bfRead.readLine();
		while(line != null && !line.equals("")) {
			if(line.charAt(0) == '#') {
				line = bfRead.readLine();
				String[] datas = line.split("\t");
				boolean catches = Boolean.parseBoolean(datas[6]);
				int rebound = Integer.parseInt(datas[5]);
				ObjPac pac = new ObjPac(Integer.parseInt(datas[1]), Integer.parseInt(datas[2]), Integer.parseInt(datas[3]), datas[4] ,Integer.parseInt(datas[0]) * 2, catches, rebound);
				pacs.add(pac);
				line = bfRead.readLine();
			}
		}
	}
	
	public void saveGame(File file) throws IOException{
		PrintWriter printW = new PrintWriter(file);
		printW.println("#Level");
		printW.println(level);
		printW.println("#radio posX posY waitTime directions rebounds");
		for(ObjPac objP: pacs) {
			printW.println((objP.getRadius() / 2) + "\t" + objP.getPosX() + "\t" + objP.getPosY() + "\t" + objP.getWaitTime() + "\t" + objP.getDirection() + "\t" + objP.getRebound() + "\t" + objP.getCatched());
			printW.close();
		}
	}
	
	public int calculateTotalRebounds() {
		int reboundsFinals = 0;
		for(ObjPac objP: pacs) {
			reboundsFinals += objP.getRebound();
		}
		return reboundsFinals;
	}
	
	public void catched(int x, int y) {
		for(int i = 0; i < pacs.size(); i++) {
			ObjPac objP = pacs.get(i);
			if(objP.catchAPac(x, y)) {
				objP.setCatched(true);
			}
		}
	}
	
	public boolean endOfTheGame() {
		boolean catcheds = true;
		for(int i = 0; i < pacs.size(); i++) {
			ObjPac objP = pacs.get(i);
			if(!objP.getCatched()) {
				catcheds = false;
			}
		}
		return catcheds;
	}
	
	public boolean savePoints() {
		int reboundTotals = calculateTotalRebounds();
		boolean save = points.hallOfFame(level, reboundTotals);
		return save;
	}
	
	public void saveActualPoint(String name) {
		points.addPoints(level, name, calculateTotalRebounds());
	}
	
	public String getPointers() {
		String msg = "";
		msg = points.showPoints();
		return msg;
	}
}
