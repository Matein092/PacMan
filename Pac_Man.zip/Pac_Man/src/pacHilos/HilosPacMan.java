package pacHilos;
import model.*;
import userInterface.*;

public class HilosPacMan extends Thread {
	private ObjPac pac;
	private Main main;

	public HilosPacMan(Main main,ObjPac pac) {
		this.pac = pac;
		this.main = main;
	}
	
	@Override
	public void run() {
		while(pac.getCatched() == false) {
			try {
				pac.movePac(main.width(), main.large());
				Thread.sleep(pac.getWaitTime());
			}
			catch(InterruptedException exception) {
				exception.printStackTrace();
			}			
		}
	}
	
	

}
